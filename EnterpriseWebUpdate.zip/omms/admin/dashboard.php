<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['oesaid'] == 0)) {
    header('location:logout.php');
} else {
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>

        <title>Annual University Magazine of FPT Greenwich University - Dashboard </title>

        <link href="../assets/css/loader.css" rel="stylesheet" type="text/css" />
        <script src="../assets/js/loader.js"></script>

        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/plugins.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->

        <!-- BEGIN PAGE LEVEL ../plugins/CUSTOM STYLES -->
        <link href="../plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
        <link href="../assets/css/dashboard/dash_2.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL ../plugins/CUSTOM STYLES -->

    </head>

    <body class="alt-menu sidebar-noneoverflow">
        <!-- BEGIN LOADER -->
        <div id="load_screen">
            <div class="loader">
                <div class="loader-content">
                    <div class="spinner-grow align-self-center"></div>
                </div>
            </div>
        </div>
        <!--  END LOADER -->

        <!--  BEGIN NAVBAR  -->
        <?php include_once('includes/header.php'); ?>
        <!--  END NAVBAR  -->

        <!--  BEGIN MAIN CONTAINER  -->
        <div class="main-container" id="container">

            <div class="overlay"></div>
            <div class="search-overlay"></div>

            <!--  BEGIN TOPBAR  -->
            <?php include_once('includes/menubar.php'); ?>
            <!--  END TOPBAR  -->

            <!--  BEGIN CONTENT PART  -->
            <div id="content" class="main-content">
                <div class="layout-px-spacing">
                    <div class="row layout-top-spacing">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                            <div class="row widget-statistic">
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-followers">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users">
                                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="9" cy="7" r="4"></circle>
                                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql = "SELECT ID from tbladmin";
                                            $query = $dbh->prepare($sql);
                                            $query->execute();
                                            $results = $query->fetchAll(PDO::FETCH_OBJ);
                                            $totuser = $query->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totuser); ?></p>
                                            <a href="reg-user.php">
                                                <h5 class="">Total Reg Staff Accounts</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-followers">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-check">
                                                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="8.5" cy="7" r="4"></circle>
                                                    <polyline points="17 11 19 13 23 9"></polyline>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql2 = "SELECT ID from tbluser where Role='Student'";
                                            $query2 = $dbh->prepare($sql2);
                                            $query2->execute();
                                            $results = $query2->fetchAll(PDO::FETCH_OBJ);
                                            $totpublmag = $query2->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totpublmag); ?></p>
                                            <a href="reg-user.php">
                                                <h5 class="">Total Student Accounts</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-followers">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
                                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="12" cy="7" r="4"></circle>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql3 = "SELECT ID from tbluser where Role='Guest'";
                                            $query3 = $dbh->prepare($sql3);
                                            $query3->execute();
                                            $results = $query3->fetchAll(PDO::FETCH_OBJ);
                                            $totnotpublmag = $query3->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totnotpublmag); ?></p>
                                            <a href="reg-user.php">
                                                <h5 class="">Total Guest Accounts</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                            <div class="row widget-statistic">
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-referral">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-book-open">
                                                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                                                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql1 = "SELECT ID from tblmagazine where Status is null";
                                            $query1 = $dbh->prepare($sql1);
                                            $query1->execute();
                                            $results = $query1->fetchAll(PDO::FETCH_OBJ);
                                            $totnewmag = $query1->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totnewmag); ?></p>
                                            <a href="new-magazine.php">
                                                <h5 class="">Total Pending Magazines </h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-referral">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-book-open">
                                                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                                                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql2 = "SELECT ID from tblmagazine where Status='Published'";
                                            $query2 = $dbh->prepare($sql2);
                                            $query2->execute();
                                            $results = $query2->fetchAll(PDO::FETCH_OBJ);
                                            $totpublmag = $query2->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totpublmag); ?></p>
                                            <a href="published.php">
                                                <h5 class="">Total Published Magazines</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-referral">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-book-open">
                                                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                                                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql3 = "SELECT ID from tblmagazine where Status='Not Published'";
                                            $query3 = $dbh->prepare($sql3);
                                            $query3->execute();
                                            $results = $query3->fetchAll(PDO::FETCH_OBJ);
                                            $totnotpublmag = $query3->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totnotpublmag); ?></p>
                                            <a href="notpublished.php">
                                                <h5 class="">Total Unpublished Magazines</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                            <div class="row widget-statistic">
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor">
                                                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                                    <line x1="8" y1="21" x2="16" y2="21"></line>
                                                    <line x1="12" y1="17" x2="12" y2="21"></line>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql1 = "SELECT ID from tblmagazine where CategoryID=1";
                                            $query1 = $dbh->prepare($sql1);
                                            $query1->execute();
                                            $results = $query1->fetchAll(PDO::FETCH_OBJ);
                                            $totpublmag = $query1->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totpublmag); ?></p>
                                            <h5 class="">Total Magazines of IT Faculty </h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign">
                                                    <line x1="12" y1="1" x2="12" y2="23"></line>
                                                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql2 = "SELECT ID from tblmagazine where CategoryID=2";
                                            $query2 = $dbh->prepare($sql2);
                                            $query2->execute();
                                            $results = $query2->fetchAll(PDO::FETCH_OBJ);
                                            $totpublmag = $query2->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totpublmag); ?></p>
                                            <h5 class="">Total Magazines of Business Faculty </h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql3 = "SELECT ID from tblmagazine where CategoryID=3";
                                            $query3 = $dbh->prepare($sql3);
                                            $query3->execute();
                                            $results = $query3->fetchAll(PDO::FETCH_OBJ);
                                            $totpublmag = $query3->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totpublmag); ?></p>
                                            <h5 class="">Total Magazines of Graphic Design Faculty</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                            <div class="row widget-statistic">
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-engagement">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-circle">
                                                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql4 = "SELECT ID from tblcomments where status=0";
                                            $query4 = $dbh->prepare($sql4);
                                            $query4->execute();
                                            $results = $query4->fetchAll(PDO::FETCH_OBJ);
                                            $totnotapp = $query4->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totnotapp); ?></p>
                                            <a href="unapprove-comment.php">
                                                <h5 class="">Total Pending Comments</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-engagement">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-circle">
                                                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql4 = "SELECT ID from tblcomments where status=0";
                                            $query4 = $dbh->prepare($sql4);
                                            $query4->execute();
                                            $results = $query4->fetchAll(PDO::FETCH_OBJ);
                                            $totnotapp = $query4->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totnotapp); ?></p>
                                            <a href="unapprove-comment.php">
                                                <h5 class="">Total Not Approved Comments</h5>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                                    <div class="widget widget-one_hybrid widget-engagement">
                                        <div class="widget-heading">
                                            <div class="w-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-circle">
                                                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                                                </svg>
                                            </div>
                                            <?php
                                            $sql5 = "SELECT ID from tblcomments where status=1";
                                            $query5 = $dbh->prepare($sql5);
                                            $query5->execute();
                                            $results = $query5->fetchAll(PDO::FETCH_OBJ);
                                            $totapp = $query5->rowCount();
                                            ?>
                                            <p class="w-value"><?php echo htmlentities($totapp); ?></p>
                                            <a href="approve-comment.php">
                                                <h5 class="">Total Approved Comments</h5>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php include_once('includes/footer.php'); ?>

                </div>
            </div>
            <!--  END CONTENT PART  -->

        </div>
        <!-- END MAIN CONTAINER -->

        <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
        <script src="../assets/js/libs/jquery-3.1.1.min.js"></script>
        <script src="../bootstrap/js/popper.min.js"></script>
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="../assets/js/app.js"></script>
        <script>
            $(document).ready(function() {
                App.init();
            });
        </script>
        <script src="../assets/js/custom.js"></script>
        <!-- END GLOBAL MANDATORY SCRIPTS -->

        <!-- BEGIN PAGE LEVEL ../plugins/CUSTOM SCRIPTS -->
        <script src="../plugins/apex/apexcharts.min.js"></script>
        <script src="../assets/js/dashboard/dash_2.js"></script>
        <!-- BEGIN PAGE LEVEL ../plugins/CUSTOM SCRIPTS -->
    </body>

    </html><?php }  ?>