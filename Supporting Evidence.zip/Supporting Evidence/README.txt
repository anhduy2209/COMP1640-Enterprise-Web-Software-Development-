********************************************** How to run the Online Magazine Management System Project Using PHP and MySQL **********************************************************************

Step 1.Find link final project to download the zip file

Step 2.Extract the file and copy omms folder

Step 3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Step 4.Open PHPMyAdmin (http://localhost/phpmyadmin)

Step 5.Create a database with name ocmdb

Step 6.Import ocmdb.sql file(given inside the zip package in SQL file folder)

Step 7.Run the script http://localhost/omms

************************************************************************************ ACCOUNT LOG IN THE SYSTEM ************************************************************************************
+ Administrator account: 
	Username: admin
	Password: Test@123
+ Marketing Manager account:  
	Username: manager
	Password: Test@123
+ Marketing Coordinator (IT Faculty) account: 
	Username: coordinatorIT
	Password: Test@123
+ Marketing Coordinator (Business Faculty) account: 
	Username: coordinatorBS
	Password: Test@123
+ Marketing Coordinator (Graphic Design Faculty) account: 
	Username: coordinatorGD
	Password: Test@123
----------------------------------------------------
+ Student 1: (IT Faculty) account: 
	Username: vytht@gmail.com
	Password: Test@123
+ Student 2: (IT Faculty) account: 
	Username: anhduy@gmail.com	
	Password: Test@123
+ Student 3: (Graphic Design Faculty) account: 
	Username: duclong@gmail.com
	Password: Test@123
+ Student 4: (Business Faculty) account: 
	Username: hoangthanh@gmail.com	
	Password: Test@123
-----------------------------------------------------