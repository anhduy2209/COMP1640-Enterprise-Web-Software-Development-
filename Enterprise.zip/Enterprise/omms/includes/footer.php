<footer class="footer-area">
	<div class="container">

		<div class="footer-bottom row align-items-center">
			<p class="footer-text m-0 col-lg-8 col-md-12">
				@ <script>
					document.write(new Date().getFullYear());
				</script> Annual University Magazine of FPT Greenwich University
			<div class="col-lg-4 col-md-12 footer-social">
				<a href="https://www.facebook.com/GreenwichVietnam"><i class="fa fa-facebook"></i></a>
				<a href="https://greenwich.edu.vn/"><i class="fa fa-dribbble"></i></a>
			</div>
			</p>
		</div>
	</div>
</footer>